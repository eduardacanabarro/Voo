/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.passagens;

/**
 *
 * @author Duda
 */
public class Passagens {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
