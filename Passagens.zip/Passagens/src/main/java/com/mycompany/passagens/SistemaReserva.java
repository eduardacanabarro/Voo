/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.passagens;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Duda
 */
public class SistemaReserva {

    public void realizarR(com.mycompany.passagens.Cliente cliente2, int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void adicionarvoo(Voo voo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static class Voo {

        public Voo() {
        }
    }
    
   
   
}
     






